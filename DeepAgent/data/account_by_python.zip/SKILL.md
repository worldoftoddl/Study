---
name: account-by-python
description: K-IFRS(한국채택국제회계기준) 기반 복식부기 분개(Journal Entry) 생성 및 검증 스킬. DART XBRL 택소노미 기반 147개 표준계정과목 + 47개 거래 패턴을 활용하여 거래 설명을 정확한 분개로 변환합니다.
version: 1.1.0
author: DeepAgent User
tags: [accounting, K-IFRS, journal-entry, XBRL, bookkeeping, 회계, 분개]
---

# K-IFRS 회계 분개 스킬

## ⚠️ 중요: 실행 방식

**이 스킬에는 이미 완성된 Python 모듈이 포함되어 있습니다.**
**절대로 코드를 새로 작성하지 마세요.**
**기존 모듈을 import하여 메서드를 호출하세요.**

```python
# ✅ 올바른 사용법: 기존 모듈 import
import sys
sys.path.insert(0, "./skills/k-ifrs-accounting")
from journal_engine import JournalEngine
from validation import JournalValidator

engine = JournalEngine(base_path="./skills/k-ifrs-accounting")
validator = JournalValidator(base_path="./skills/k-ifrs-accounting")

# ❌ 잘못된 사용법: 코드를 새로 작성하는 것
# json.load(open("chart_of_accounts.json"))  ← 이렇게 하지 마세요
# for account in data["accounts"]: ...       ← 이렇게 하지 마세요
```

## 개요

이 스킬은 자연어 거래 설명을 K-IFRS 표준 복식부기 분개로 변환합니다.

**핵심 능력:**
- 거래 설명 → 차변/대변 분개 자동 생성
- K-IFRS 표준계정과목 체계 기반 (DART XBRL 택소노미)
- 4단계 검증 (대차균형 → 계정유효성 → Balance방향 → 비즈니스규칙)
- 하이브리드 엔진: 47개 정의된 패턴 + LLM 추론 (미정의 거래)

## 파일 구조

```
k-ifrs-accounting/
├── SKILL.md                              ← 지금 읽고 있는 파일
├── journal_engine.py                     ← 분개 생성 엔진 (import하여 사용)
├── validation.py                         ← 분개 검증 모듈 (import하여 사용)
└── references/
    ├── chart_of_accounts.json            ← K-IFRS 표준계정과목 (147개)
    └── transaction_patterns.json         ← 거래 유형별 분개 패턴 (47개)
```

**JSON 파일은 직접 열지 마세요.** `JournalEngine`과 `JournalValidator`가 초기화 시 자동으로 로드합니다.

## 거래 처리 워크플로우

사용자로부터 거래 설명을 받으면 다음 순서대로 처리합니다:

### Step 1: 엔진 초기화 (최초 1회)

```python
import sys
sys.path.insert(0, "./skills/k-ifrs-accounting")
from journal_engine import JournalEngine
from validation import JournalValidator

engine = JournalEngine(base_path="./skills/k-ifrs-accounting")
validator = JournalValidator(base_path="./skills/k-ifrs-accounting")
```

### Step 2: 패턴 매칭 시도

```python
matches = engine.find_matching_patterns("상품을 외상으로 판매했다")
```

### Step 3A: 패턴이 있으면 → 패턴 기반 분개 생성

```python
if matches:
    entry = engine.create_entry_from_pattern(
        pattern_id=matches[0]["pattern_id"],
        variables={"amount": 10_000_000, "vat": 1_000_000},
        description="A사에 상품 1,000만원 외상판매 (VAT 별도)"
    )
```

### Step 3B: 패턴이 없으면 → LLM 추론

```python
if not matches:
    # 추론 컨텍스트 획득 (관련 계정, 유사 패턴, 규칙)
    context = engine.get_inference_context("복잡한 거래 설명")
    
    # context 내용을 참고하여 분개를 추론한 후:
    entry = engine.create_manual_entry(
        description="추론된 거래",
        lines=[
            {"side": "debit", "account_id": "ifrs-full_CashAndCashEquivalents", "amount": 500_000},
            {"side": "credit", "account_id": "ifrs-full_Revenue", "amount": 500_000},
        ]
    )
```

### Step 4: 검증

```python
result = validator.validate(entry)
```

### Step 5: 결과 출력

```python
print(entry.format_korean())    # 분개 표시
print(result.format_korean())   # 검증 결과 표시
```

## 주요 API 레퍼런스

### JournalEngine 메서드

| 메서드 | 용도 | 반환 |
|--------|------|------|
| `find_matching_patterns(description)` | 거래 설명으로 패턴 검색 | list[dict] |
| `create_entry_from_pattern(pattern_id, variables, description)` | 패턴 기반 분개 생성 | JournalEntry |
| `create_manual_entry(description, lines)` | 직접 분개 구성 (LLM 추론용) | JournalEntry |
| `get_inference_context(description)` | LLM 추론용 컨텍스트 | dict |
| `search_accounts(keyword)` | 계정과목 키워드 검색 | list[dict] |
| `get_account(account_id)` | 계정과목 ID 조회 | dict or None |
| `get_accounts_by_category(category)` | 카테고리별 조회 | list[dict] |
| `get_pattern_list()` | 전체 패턴 목록 | list[dict] |

### JournalValidator 메서드

| 메서드 | 용도 | 반환 |
|--------|------|------|
| `validate(entry)` | JournalEntry 객체 검증 | ValidationResult |
| `validate_raw(lines)` | 딕셔너리 리스트 검증 | ValidationResult |

### variables 딕셔너리 규칙

패턴마다 요구하는 변수가 다릅니다. 일반적인 변수:

| 변수명 | 설명 | 예시 |
|--------|------|------|
| `amount` | 주 거래 금액 | 10_000_000 |
| `vat` | 부가가치세 | 1_000_000 |
| `book_value` | 장부금액 | 80_000_000 |
| `sale_price` | 매각가액 | 90_000_000 |
| `gain` / `loss` | 처분이익/손실 | 10_000_000 |

## 분개 추론 규칙 (LLM용)

패턴에 매칭되지 않는 거래를 `create_manual_entry`로 처리할 때, 다음 규칙을 따릅니다:

### 기본 원리: 계정의 자연적 잔액(Natural Balance)

| 계정 분류 | 자연적 잔액 | 증가 시 | 감소 시 |
|-----------|-----------|---------|---------|
| 자산 (asset) | Debit | 차변 기입 | 대변 기입 |
| 부채 (liability) | Credit | 대변 기입 | 차변 기입 |
| 자본 (equity) | Credit | 대변 기입 | 차변 기입 |
| 수익 (revenue) | Credit | 대변 기입 | 차변 기입 |
| 비용 (expense) | Debit | 차변 기입 | 대변 기입 |

### Contra(차감) 계정 주의

차감 계정은 원래 계정과 **반대 방향**입니다:
- 대손충당금 (contra_asset) → Credit balance
- 감가상각누계액 (contra_asset) → Credit balance
- 사채할인발행차금 (contra_liability) → Debit balance
- 자기주식 (contra_equity) → Debit balance
- 매출에누리 (contra_revenue) → Debit balance

### 추론 절차

1. `engine.get_inference_context(description)` 호출하여 관련 계정과 규칙 획득
2. 각 계정의 `balance` 속성(debit/credit)을 확인
3. 계정의 자연적 잔액 방향으로 금액이 증가하면 해당 방향에 기입
4. **차변 합계 = 대변 합계** (대차평균의 원리) 반드시 확인
5. `engine.create_manual_entry()`로 분개 생성
6. `validator.validate()`로 검증
7. 불확실한 경우 사용자에게 확인 요청

## K-IFRS 특수 비즈니스 규칙

검증 모듈이 자동으로 체크하는 규칙들:

1. **영업권 손상환입 불가** (IAS 36.124): 영업권의 손상차손은 후속 기간에 환입할 수 없음
2. **추상(abstract) 계정 사용 불가**: "자산", "유동자산" 등 분류 계정은 분개에 직접 사용 불가
3. **감가상각누계액 차변 기입**: 자산 처분 거래가 아닌 경우 경고
4. **소계/합계 계정 사용 경고**: "매출총이익", "영업이익" 등은 분개 계정이 아님

## 주요 패턴 카테고리

| 카테고리 | ID 접두사 | 패턴 수 | 설명 |
|---------|----------|---------|------|
| 매출 | SALE_ | 4 | 현금/외상 매출, 채권 회수, 반품 |
| 매입 | PUR_ | 3 | 현금/외상 매입, 채무 지급 |
| 유형자산 | PPE_ | 4 | 취득, 감가상각, 처분(이익/손실) |
| 급여 | PAYROLL_ | 2 | 급여 지급, 퇴직급여 설정 |
| 차입/사채 | LOAN_ | 6 | 단기/장기 차입, 상환, 이자, 사채 |
| 자본 | EQUITY_ | 4 | 유상증자, 배당, 자기주식 |
| 일반비용 | EXP_ | 4 | 현금지급, 미지급, 선급비용 |
| 채권관리 | RCV_ | 2 | 대손충당금 설정, 대손 확정 |
| 세금 | TAX_ | 3 | 법인세, 부가세 |
| 금융상품 | FIN_ | 4 | 이자수익, FVTPL 취득/평가 |
| 리스 | LEASE_ | 2 | IFRS 16 리스 개시, 리스료 |
| 재고 | INV_ | 1 | 재고평가손실 |
| 외환 | FX_ | 1 | 외환차익 |
| 결산조정 | ADJ_ | 5 | 선수수익, 미수수익, 선급금 등 |
| 손상 | IMPAIR_ | 2 | 손상차손, 손상환입 |

## 데이터 출처

- **계정과목**: DART XBRL 택소노미 (K-IFRS 2024) 기반 구조
  - `ifrs-full_` 접두사: IFRS 글로벌 표준 계정
  - `dart_` 접두사: DART 한국 확장 계정
- **Balance 속성**: XBRL `xbrli:balance` 규격 + CPA 규칙 기반 보강
- **분개 패턴**: K-IFRS 실무 기반 수작업 정의

## 제한사항

1. 연결재무제표 연결조정 분개는 미포함 (별도/개별 기준)
2. 업종별 특수 계정과목 (금융업, 건설업 등)은 부분 포함
3. DART API 실시간 연동은 미구현 (오프라인 데이터 기반)
4. 세무조정(법인세 신고) 분개는 범위 밖
