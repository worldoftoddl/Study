"""
K-IFRS 분개 검증 모듈 (Validation Module)
==========================================
생성된 분개의 정확성을 다층 검증:
  Level 1: 대차 균형 (차변 합계 = 대변 합계)
  Level 2: 계정과목 유효성 (chart_of_accounts 존재 여부)
  Level 3: Balance 방향 적정성 (계정의 자연적 잔액 방향 검증)
  Level 4: 비즈니스 규칙 (K-IFRS 특수 규칙)
"""

import json
import os
from typing import Optional
from dataclasses import dataclass, field, asdict


@dataclass
class ValidationIssue:
    """검증 이슈 하나"""
    level: int              # 1~4
    severity: str           # "error", "warning", "info"
    code: str               # 이슈 코드
    message: str            # 한국어 설명
    account_id: str = ""    # 관련 계정과목 (있는 경우)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ValidationResult:
    """검증 결과 종합"""
    is_valid: bool = True
    issues: list = field(default_factory=list)  # list[ValidationIssue]
    summary: str = ""

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "error")

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "warning")

    def add_issue(self, issue: ValidationIssue):
        self.issues.append(issue)
        if issue.severity == "error":
            self.is_valid = False

    def to_dict(self) -> dict:
        return {
            "is_valid": self.is_valid,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "summary": self.summary,
            "issues": [i.to_dict() for i in self.issues],
        }

    def format_korean(self) -> str:
        """한국어 검증 결과 표시"""
        lines = []
        status = "✅ 검증 통과" if self.is_valid else "❌ 검증 실패"
        lines.append(f"[검증 결과] {status}")
        lines.append(f"  오류: {self.error_count}건, 경고: {self.warning_count}건")

        if self.issues:
            lines.append("")
            for issue in self.issues:
                icon = {"error": "❌", "warning": "⚠️", "info": "ℹ️"}.get(issue.severity, "?")
                lines.append(f"  {icon} [L{issue.level}] {issue.message}")
                if issue.account_id:
                    lines.append(f"       계정: {issue.account_id}")

        if self.summary:
            lines.append(f"\n  요약: {self.summary}")

        return "\n".join(lines)


class JournalValidator:
    """
    분개 검증기

    사용법:
        validator = JournalValidator()
        result = validator.validate(journal_entry)
        print(result.format_korean())
    """

    def __init__(self, base_path: Optional[str] = None):
        if base_path is None:
            base_path = os.path.dirname(os.path.abspath(__file__))

        ref_path = os.path.join(base_path, "references")

        with open(os.path.join(ref_path, "chart_of_accounts.json"), "r", encoding="utf-8") as f:
            coa_data = json.load(f)
        self._accounts = {a["account_id"]: a for a in coa_data["accounts"]}

    def validate(self, entry) -> ValidationResult:
        """
        JournalEntry 객체를 종합 검증.

        Args:
            entry: JournalEntry (journal_engine.py에서 생성)

        Returns:
            ValidationResult
        """
        result = ValidationResult()

        # Level 1: 대차 균형
        self._validate_balance(entry, result)

        # Level 2: 계정과목 유효성
        self._validate_accounts(entry, result)

        # Level 3: Balance 방향 적정성
        self._validate_balance_direction(entry, result)

        # Level 4: 비즈니스 규칙
        self._validate_business_rules(entry, result)

        # 요약 생성
        if result.is_valid:
            result.summary = "분개가 모든 검증을 통과했습니다."
        else:
            result.summary = f"분개에 {result.error_count}건의 오류가 있습니다. 수정이 필요합니다."

        return result

    def validate_raw(self, lines: list) -> ValidationResult:
        """
        딕셔너리 리스트 형태의 분개를 검증.
        LLM이 직접 생성한 raw 데이터 검증 시 사용.

        Args:
            lines: [{"side": "debit"/"credit", "account_id": "...", "amount": 금액}, ...]
        """
        result = ValidationResult()

        # 빈 분개 체크
        if not lines:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="EMPTY_ENTRY",
                message="분개에 항목이 없습니다."
            ))
            return result

        # Level 1: 대차 균형
        debit_total = sum(l.get("amount", 0) for l in lines if l.get("side") == "debit")
        credit_total = sum(l.get("amount", 0) for l in lines if l.get("side") == "credit")

        if abs(debit_total - credit_total) >= 0.01:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="UNBALANCED",
                message=f"차변({debit_total:,.0f}) ≠ 대변({credit_total:,.0f}). "
                        f"차이: {abs(debit_total - credit_total):,.0f}"
            ))

        for line in lines:
            account_id = line.get("account_id", "")

            # Level 2: 계정과목 유효성
            if account_id and not account_id.startswith("__"):
                acc = self._accounts.get(account_id)
                if not acc:
                    result.add_issue(ValidationIssue(
                        level=2, severity="error",
                        code="INVALID_ACCOUNT",
                        message=f"'{account_id}'는 K-IFRS 표준계정과목에 존재하지 않습니다.",
                        account_id=account_id
                    ))
                elif acc.get("is_abstract", False):
                    result.add_issue(ValidationIssue(
                        level=2, severity="error",
                        code="ABSTRACT_ACCOUNT",
                        message=f"'{acc['account_nm']}'({account_id})는 추상(abstract) 계정으로 "
                                f"직접 분개에 사용할 수 없습니다. 하위 계정과목을 사용하세요.",
                        account_id=account_id
                    ))

            # 금액 검증
            amount = line.get("amount", 0)
            if amount <= 0:
                result.add_issue(ValidationIssue(
                    level=1, severity="error",
                    code="INVALID_AMOUNT",
                    message=f"금액이 0 이하입니다: {amount}",
                    account_id=account_id
                ))

            # side 검증
            side = line.get("side", "")
            if side not in ("debit", "credit"):
                result.add_issue(ValidationIssue(
                    level=1, severity="error",
                    code="INVALID_SIDE",
                    message=f"유효하지 않은 구분: '{side}' (debit 또는 credit이어야 합니다)",
                    account_id=account_id
                ))

            # Level 3: Balance 방향
            if account_id and not account_id.startswith("__"):
                acc = self._accounts.get(account_id)
                if acc and side in ("debit", "credit"):
                    natural_balance = acc["balance"]
                    category = acc.get("category", "")

                    # contra 계정은 자연적 잔액 방향이 이미 반대이므로 검증 스킵
                    if "contra" not in category and side != natural_balance:
                        result.add_issue(ValidationIssue(
                            level=3, severity="warning",
                            code="REVERSE_BALANCE",
                            message=f"'{acc['account_nm']}'의 자연적 잔액은 {natural_balance}이지만 "
                                    f"{side}에 기입되었습니다. "
                                    f"해당 계정의 감소 거래가 맞다면 정상입니다.",
                            account_id=account_id
                        ))

        return result

    # ── Level 1: 대차 균형 ───────────────────────────────────────

    def _validate_balance(self, entry, result: ValidationResult):
        """대차 균형 검증"""
        if not entry.lines:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="EMPTY_ENTRY",
                message="분개에 항목이 없습니다."
            ))
            return

        if not entry.is_balanced:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="UNBALANCED",
                message=f"차변({entry.debit_total:,.0f}) ≠ 대변({entry.credit_total:,.0f}). "
                        f"차이: {abs(entry.debit_total - entry.credit_total):,.0f}"
            ))

        # 최소 차변 1개 + 대변 1개 확인
        debit_count = sum(1 for l in entry.lines if l.side == "debit")
        credit_count = sum(1 for l in entry.lines if l.side == "credit")

        if debit_count == 0:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="NO_DEBIT",
                message="차변 항목이 없습니다."
            ))
        if credit_count == 0:
            result.add_issue(ValidationIssue(
                level=1, severity="error",
                code="NO_CREDIT",
                message="대변 항목이 없습니다."
            ))

    # ── Level 2: 계정과목 유효성 ─────────────────────────────────

    def _validate_accounts(self, entry, result: ValidationResult):
        """계정과목 유효성 검증"""
        for line in entry.lines:
            account_id = line.account_id

            # 플레이스홀더 계정 스킵
            if account_id.startswith("__") and account_id.endswith("__"):
                result.add_issue(ValidationIssue(
                    level=2, severity="warning",
                    code="PLACEHOLDER_ACCOUNT",
                    message=f"플레이스홀더 계정 '{account_id}'가 사용되었습니다. "
                            f"구체적인 계정과목으로 대체해야 합니다."
                ))
                continue

            acc = self._accounts.get(account_id)

            if not acc:
                result.add_issue(ValidationIssue(
                    level=2, severity="error",
                    code="INVALID_ACCOUNT",
                    message=f"'{account_id}'는 K-IFRS 표준계정과목에 존재하지 않습니다.",
                    account_id=account_id
                ))
            elif acc.get("is_abstract", False):
                result.add_issue(ValidationIssue(
                    level=2, severity="error",
                    code="ABSTRACT_ACCOUNT",
                    message=f"'{acc['account_nm']}'({account_id})는 추상(abstract) 계정입니다. "
                            f"하위 구체 계정과목을 사용하세요.",
                    account_id=account_id
                ))

            # 금액 유효성
            if line.amount <= 0:
                result.add_issue(ValidationIssue(
                    level=2, severity="error",
                    code="INVALID_AMOUNT",
                    message=f"'{line.account_nm}'의 금액이 0 이하입니다: {line.amount}",
                    account_id=account_id
                ))

    # ── Level 3: Balance 방향 적정성 ─────────────────────────────

    def _validate_balance_direction(self, entry, result: ValidationResult):
        """계정의 자연적 잔액 방향과 분개 방향의 적정성 검증"""
        for line in entry.lines:
            if line.account_id.startswith("__"):
                continue

            acc = self._accounts.get(line.account_id)
            if not acc:
                continue

            natural_balance = acc["balance"]
            category = acc.get("category", "")

            # contra 계정은 이미 자연적 잔액이 반대이므로 패스
            if "contra" in category:
                continue

            if line.side != natural_balance:
                result.add_issue(ValidationIssue(
                    level=3, severity="warning",
                    code="REVERSE_BALANCE",
                    message=f"'{acc['account_nm']}'의 자연적 잔액은 {natural_balance}이지만 "
                            f"{line.side}에 기입되었습니다. 감소 거래가 맞다면 정상입니다.",
                    account_id=line.account_id
                ))

    # ── Level 4: 비즈니스 규칙 ───────────────────────────────────

    def _validate_business_rules(self, entry, result: ValidationResult):
        """K-IFRS 특수 비즈니스 규칙 검증"""

        account_ids = {l.account_id for l in entry.lines}

        # 규칙 1: 영업권 손상차손환입 불가
        if ("ifrs-full_Goodwill" in account_ids and
            "dart_ReversalOfImpairmentLoss" in account_ids):
            result.add_issue(ValidationIssue(
                level=4, severity="error",
                code="GOODWILL_IMPAIRMENT_REVERSAL",
                message="K-IFRS에서 영업권(goodwill) 손상차손은 환입이 불가합니다. "
                        "(IAS 36.124)",
                account_id="ifrs-full_Goodwill"
            ))

        # 규칙 2: 감가상각누계액이 차변에 단독 등장 (처분 거래가 아닌 경우)
        dep_acc_id = "ifrs-full_AccumulatedDepreciationAndAmortisationPropertyPlantAndEquipment"
        for line in entry.lines:
            if (line.account_id == dep_acc_id and
                line.side == "debit"):
                # 처분 거래인지 확인 (PPE가 대변에 있으면 처분)
                ppe_in_credit = any(
                    l.account_id == "ifrs-full_PropertyPlantAndEquipment" and l.side == "credit"
                    for l in entry.lines
                )
                if not ppe_in_credit:
                    result.add_issue(ValidationIssue(
                        level=4, severity="warning",
                        code="ACCUM_DEP_UNUSUAL",
                        message="감가상각누계액이 차변에 기입되었지만 유형자산 처분 거래가 아닌 것 같습니다. "
                                "감가상각누계액의 차변 기입은 주로 자산 처분 시에만 발생합니다.",
                        account_id=dep_acc_id
                    ))

        # 규칙 3: 자기주식이 대변에 단독 (자기주식 처분 시에만 정상)
        for line in entry.lines:
            if (line.account_id == "ifrs-full_TreasuryShares" and
                line.side == "credit"):
                result.add_issue(ValidationIssue(
                    level=4, severity="info",
                    code="TREASURY_SHARE_CREDIT",
                    message="자기주식이 대변에 기입되었습니다. "
                            "자기주식 처분 또는 소각 거래가 맞는지 확인하세요.",
                    account_id="ifrs-full_TreasuryShares"
                ))

        # 규칙 4: subtotal 계정 사용 경고
        for line in entry.lines:
            acc = self._accounts.get(line.account_id)
            if acc and acc.get("category") == "subtotal":
                result.add_issue(ValidationIssue(
                    level=4, severity="warning",
                    code="SUBTOTAL_ACCOUNT_USED",
                    message=f"'{acc['account_nm']}'은(는) 소계/합계 계정입니다. "
                            f"실제 분개에서는 일반적으로 사용하지 않습니다.",
                    account_id=line.account_id
                ))


# ── CLI 테스트 ───────────────────────────────────────────────────

if __name__ == "__main__":
    from journal_engine import JournalEngine

    engine = JournalEngine()
    validator = JournalValidator()

    # 테스트 1: 정상 분개
    print("=" * 60)
    print("테스트 1: 정상 외상매출 분개")
    entry = engine.create_entry_from_pattern(
        "SALE_001",
        {"amount": 10_000_000, "vat": 1_000_000},
        "A사에 상품 외상판매"
    )
    print(entry.format_korean())
    result = validator.validate(entry)
    print(result.format_korean())

    # 테스트 2: 불균형 분개 (수동 생성)
    print("\n" + "=" * 60)
    print("테스트 2: 불균형 분개")
    bad_entry = engine.create_manual_entry(
        "잘못된 분개 테스트",
        [
            {"side": "debit", "account_id": "ifrs-full_CashAndCashEquivalents", "amount": 100_000},
            {"side": "credit", "account_id": "ifrs-full_Revenue", "amount": 90_000},
        ]
    )
    print(bad_entry.format_korean())
    result2 = validator.validate(bad_entry)
    print(result2.format_korean())

    # 테스트 3: 비즈니스 규칙 위반 (영업권 손상환입)
    print("\n" + "=" * 60)
    print("테스트 3: 영업권 손상환입 시도")
    illegal_entry = engine.create_manual_entry(
        "영업권 손상차손환입 (위반)",
        [
            {"side": "debit", "account_id": "ifrs-full_Goodwill", "amount": 500_000},
            {"side": "credit", "account_id": "dart_ReversalOfImpairmentLoss", "amount": 500_000},
        ]
    )
    print(illegal_entry.format_korean())
    result3 = validator.validate(illegal_entry)
    print(result3.format_korean())
