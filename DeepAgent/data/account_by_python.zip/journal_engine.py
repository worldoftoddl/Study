"""
K-IFRS 분개 엔진 (Journal Entry Engine)
========================================
거래 설명 → 분개(Journal Entry) 생성

사용 방식:
  1. 패턴 매칭: transaction_patterns.json에서 키워드 기반 매칭
  2. LLM 추론: 매칭 실패 시 chart_of_accounts.json 기반 추론 컨텍스트 제공

이 모듈은 DeepAgent Skill에서 호출됩니다.
"""

import json
import os
import re
from typing import Optional
from dataclasses import dataclass, field, asdict


# ── 데이터 클래스 정의 ──────────────────────────────────────────────

@dataclass
class JournalLine:
    """분개 한 줄 (차변 또는 대변)"""
    side: str           # "debit" or "credit"
    account_id: str     # XBRL element ID
    account_nm: str     # 한국어 계정과목명
    amount: float       # 금액
    label: str = ""     # 표시 라벨

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class JournalEntry:
    """하나의 분개 전표"""
    transaction_description: str
    pattern_id: Optional[str]       # 매칭된 패턴 ID (없으면 None = LLM 추론)
    pattern_name: Optional[str]     # 매칭된 패턴명
    lines: list = field(default_factory=list)  # list[JournalLine]
    is_balanced: bool = False       # 차대 균형 여부
    warnings: list = field(default_factory=list)

    def add_line(self, line: JournalLine):
        self.lines.append(line)
        self._check_balance()

    def _check_balance(self):
        debit_total = sum(l.amount for l in self.lines if l.side == "debit")
        credit_total = sum(l.amount for l in self.lines if l.side == "credit")
        self.is_balanced = abs(debit_total - credit_total) < 0.01

    @property
    def debit_total(self) -> float:
        return sum(l.amount for l in self.lines if l.side == "debit")

    @property
    def credit_total(self) -> float:
        return sum(l.amount for l in self.lines if l.side == "credit")

    def to_dict(self) -> dict:
        return {
            "transaction_description": self.transaction_description,
            "pattern_id": self.pattern_id,
            "pattern_name": self.pattern_name,
            "lines": [l.to_dict() for l in self.lines],
            "debit_total": self.debit_total,
            "credit_total": self.credit_total,
            "is_balanced": self.is_balanced,
            "warnings": self.warnings,
        }

    def format_korean(self) -> str:
        """한국어 분개 표시 형식"""
        lines_out = []
        lines_out.append(f"[분개] {self.transaction_description}")
        if self.pattern_id:
            lines_out.append(f"  패턴: {self.pattern_name} ({self.pattern_id})")
        lines_out.append("-" * 60)
        lines_out.append(f"{'구분':<6} {'계정과목':<25} {'금액':>15}")
        lines_out.append("-" * 60)
        for l in self.lines:
            side_kr = "(차) " if l.side == "debit" else "  (대)"
            lines_out.append(f"{side_kr} {l.account_nm:<23} {l.amount:>15,.0f}")
        lines_out.append("-" * 60)
        lines_out.append(f"{'차변 합계':<30} {self.debit_total:>15,.0f}")
        lines_out.append(f"{'대변 합계':<30} {self.credit_total:>15,.0f}")
        balanced_str = "✅ 대차 균형" if self.is_balanced else "❌ 대차 불균형"
        lines_out.append(f"  → {balanced_str}")
        if self.warnings:
            lines_out.append("\n⚠️ 경고:")
            for w in self.warnings:
                lines_out.append(f"  - {w}")
        return "\n".join(lines_out)


# ── 엔진 클래스 ─────────────────────────────────────────────────────

class JournalEngine:
    """
    K-IFRS 분개 생성 엔진

    사용법:
        engine = JournalEngine()
        
        # 패턴 기반 분개 생성
        entry = engine.create_entry_from_pattern(
            "SALE_001",
            {"amount": 1000000, "vat": 100000}
        )
        
        # 키워드 검색으로 패턴 찾기
        matches = engine.find_matching_patterns("외상매출")
        
        # LLM 추론용 컨텍스트 생성
        context = engine.get_inference_context("리스 계약 체결")
    """

    def __init__(self, base_path: Optional[str] = None):
        if base_path is None:
            base_path = os.path.dirname(os.path.abspath(__file__))
        
        ref_path = os.path.join(base_path, "references")
        
        # 데이터 로드
        with open(os.path.join(ref_path, "chart_of_accounts.json"), "r", encoding="utf-8") as f:
            coa_data = json.load(f)
        self._accounts = {a["account_id"]: a for a in coa_data["accounts"]}
        self._balance_rules = coa_data.get("_balance_rules", {})

        with open(os.path.join(ref_path, "transaction_patterns.json"), "r", encoding="utf-8") as f:
            pat_data = json.load(f)
        self._patterns = {p["id"]: p for p in pat_data["patterns"]}
        self._llm_guide = pat_data.get("_llm_inference_guide", {})

    # ── 계정과목 조회 ────────────────────────────────────────────

    def get_account(self, account_id: str) -> Optional[dict]:
        """계정과목 ID로 조회"""
        return self._accounts.get(account_id)

    def search_accounts(self, keyword: str) -> list:
        """한국어 또는 영어 키워드로 계정과목 검색"""
        keyword_lower = keyword.lower()
        results = []
        for acc in self._accounts.values():
            if (keyword in acc["account_nm"] or
                keyword_lower in acc.get("account_nm_en", "").lower() or
                keyword_lower in acc["account_id"].lower()):
                results.append(acc)
        return results

    def get_accounts_by_category(self, category: str) -> list:
        """카테고리별 계정과목 조회 (asset, liability, equity, revenue, expense 등)"""
        return [a for a in self._accounts.values() if a["category"] == category]

    # ── 패턴 매칭 ────────────────────────────────────────────────

    def find_matching_patterns(self, description: str) -> list:
        """
        거래 설명에서 키워드 매칭으로 적용 가능한 패턴을 찾음.
        
        Returns:
            매칭된 패턴 목록 (매칭 점수 내림차순 정렬)
        """
        results = []
        desc_lower = description.lower()
        
        for pat_id, pat in self._patterns.items():
            score = 0
            matched_keywords = []
            
            for kw in pat.get("keywords", []):
                if kw in description or kw.lower() in desc_lower:
                    score += len(kw)  # 긴 키워드일수록 높은 점수
                    matched_keywords.append(kw)
            
            # 패턴 이름도 매칭 시도
            if pat["name"] in description:
                score += 5
            
            if score > 0:
                results.append({
                    "pattern_id": pat_id,
                    "pattern_name": pat["name"],
                    "score": score,
                    "matched_keywords": matched_keywords,
                    "description": pat["description"],
                })
        
        results.sort(key=lambda x: x["score"], reverse=True)
        return results

    # ── 분개 생성 (패턴 기반) ────────────────────────────────────

    def create_entry_from_pattern(
        self,
        pattern_id: str,
        variables: dict,
        description: str = ""
    ) -> JournalEntry:
        """
        패턴 ID와 변수값으로 분개 생성.
        
        Args:
            pattern_id: 패턴 ID (예: "SALE_001")
            variables: 금액 변수 딕셔너리 (예: {"amount": 1000000, "vat": 100000})
            description: 거래 설명 (선택)
            
        Returns:
            JournalEntry 객체
        """
        pattern = self._patterns.get(pattern_id)
        if not pattern:
            raise ValueError(f"패턴을 찾을 수 없습니다: {pattern_id}")

        entry = JournalEntry(
            transaction_description=description or pattern["description"],
            pattern_id=pattern_id,
            pattern_name=pattern["name"],
        )

        for line_def in pattern["entries"]:
            # 금액 계산
            amount = self._evaluate_amount(line_def["amount"], variables)
            
            # 계정과목 확인
            account_id = line_def["account_id"]
            
            # 플레이스홀더 계정 처리
            if account_id.startswith("__") and account_id.endswith("__"):
                entry.warnings.append(
                    f"'{line_def['label']}' 계정은 거래 내용에 따라 구체적 계정과목을 선택해야 합니다."
                )
                account_nm = line_def["label"]
            else:
                acc = self.get_account(account_id)
                if acc:
                    account_nm = acc["account_nm"]
                else:
                    account_nm = line_def.get("label", account_id)
                    entry.warnings.append(
                        f"계정과목 '{account_id}'가 chart_of_accounts에 없습니다."
                    )

            journal_line = JournalLine(
                side=line_def["side"],
                account_id=account_id,
                account_nm=account_nm,
                amount=amount,
                label=line_def.get("label", ""),
            )
            entry.add_line(journal_line)

        return entry

    # ── 분개 생성 (직접 구성) ────────────────────────────────────

    def create_manual_entry(
        self,
        description: str,
        lines: list
    ) -> JournalEntry:
        """
        LLM이 추론한 결과를 직접 분개로 구성.
        
        Args:
            description: 거래 설명
            lines: [{"side": "debit"/"credit", "account_id": "...", "amount": 금액}, ...]
            
        Returns:
            JournalEntry 객체
        """
        entry = JournalEntry(
            transaction_description=description,
            pattern_id=None,
            pattern_name="LLM 추론",
        )

        for line_data in lines:
            account_id = line_data["account_id"]
            acc = self.get_account(account_id)
            
            if acc:
                account_nm = acc["account_nm"]
                # balance 방향 검증
                expected_balance = acc["balance"]
                side = line_data["side"]
                
                # 자연적 잔액 방향과 반대로 기입되는 경우 경고 (감소 거래일 수 있으므로 warning만)
                if side != expected_balance and "contra" not in acc.get("category", ""):
                    entry.warnings.append(
                        f"'{account_nm}'({account_id})의 자연적 잔액은 {expected_balance}이지만 "
                        f"{side}에 기입되었습니다. 해당 계정의 감소 거래가 맞는지 확인하세요."
                    )
            else:
                account_nm = line_data.get("account_nm", account_id)
                entry.warnings.append(
                    f"계정과목 '{account_id}'가 chart_of_accounts에 없습니다."
                )

            journal_line = JournalLine(
                side=line_data["side"],
                account_id=account_id,
                account_nm=account_nm,
                amount=line_data["amount"],
                label=line_data.get("label", ""),
            )
            entry.add_line(journal_line)

        return entry

    # ── LLM 추론 컨텍스트 ────────────────────────────────────────

    def get_inference_context(self, description: str) -> dict:
        """
        패턴 매칭 실패 시, LLM이 분개를 추론하기 위한 컨텍스트 생성.
        
        Returns:
            LLM에게 전달할 컨텍스트 딕셔너리:
            - related_accounts: 거래 관련 추정 계정과목들
            - inference_rules: 분개 추론 규칙
            - similar_patterns: 유사한 패턴 (참고용)
        """
        # 1. 키워드로 관련 계정 찾기
        keywords = self._extract_keywords(description)
        related_accounts = []
        for kw in keywords:
            found = self.search_accounts(kw)
            related_accounts.extend(found)
        
        # 중복 제거
        seen_ids = set()
        unique_accounts = []
        for acc in related_accounts:
            if acc["account_id"] not in seen_ids:
                seen_ids.add(acc["account_id"])
                unique_accounts.append(acc)

        # 2. 유사 패턴 (점수 낮아도 포함)
        similar_patterns = []
        for pat_id, pat in self._patterns.items():
            for kw in pat.get("keywords", []):
                if any(k in kw or kw in k for k in keywords):
                    similar_patterns.append({
                        "pattern_id": pat_id,
                        "name": pat["name"],
                        "description": pat["description"],
                    })
                    break
        
        return {
            "transaction_description": description,
            "related_accounts": unique_accounts[:20],  # 최대 20개
            "inference_rules": self._llm_guide.get("rules", []),
            "balance_table": self._llm_guide.get("balance_increase_decrease_table", {}),
            "similar_patterns": similar_patterns[:5],  # 최대 5개
        }

    # ── 내부 유틸리티 ────────────────────────────────────────────

    def _evaluate_amount(self, amount_expr: str, variables: dict) -> float:
        """금액 표현식 평가 (예: "{amount} + {vat}")"""
        expr = str(amount_expr)
        for key, value in variables.items():
            expr = expr.replace(f"{{{key}}}", str(value))
        
        try:
            # 안전한 수식 평가 (사칙연산만 허용)
            if re.match(r'^[\d\s\+\-\*\/\.\(\)]+$', expr):
                return float(eval(expr))
            else:
                raise ValueError(f"안전하지 않은 수식: {expr}")
        except Exception as e:
            raise ValueError(f"금액 계산 오류: {amount_expr} → {expr}: {e}")

    def _extract_keywords(self, text: str) -> list:
        """텍스트에서 회계 관련 키워드 추출 (간단한 토큰화)"""
        # 공백/특수문자로 분리 후 1글자 이상인 것만
        tokens = re.split(r'[\s,.\-()（）\[\]]+', text)
        keywords = [t.strip() for t in tokens if len(t.strip()) >= 2]
        return keywords

    # ── 통계/정보 ────────────────────────────────────────────────

    @property
    def account_count(self) -> int:
        return len(self._accounts)

    @property
    def pattern_count(self) -> int:
        return len(self._patterns)

    def get_pattern_list(self) -> list:
        """전체 패턴 목록 반환"""
        return [
            {
                "id": p["id"],
                "name": p["name"],
                "description": p["description"],
                "keywords": p.get("keywords", []),
            }
            for p in self._patterns.values()
        ]


# ── CLI 테스트 ───────────────────────────────────────────────────

if __name__ == "__main__":
    engine = JournalEngine()
    
    print(f"계정과목: {engine.account_count}개, 분개 패턴: {engine.pattern_count}개")
    print()
    
    # 테스트 1: 외상매출
    entry = engine.create_entry_from_pattern(
        "SALE_001",
        {"amount": 10_000_000, "vat": 1_000_000},
        "A사에 상품 1,000만원 외상판매 (부가세 별도)"
    )
    print(entry.format_korean())
    print()
    
    # 테스트 2: 감가상각
    entry2 = engine.create_entry_from_pattern(
        "PPE_002",
        {"amount": 5_000_000},
        "기계장치 월 감가상각비 인식"
    )
    print(entry2.format_korean())
    print()
    
    # 테스트 3: 키워드 검색
    matches = engine.find_matching_patterns("외상으로 상품을 매출했다")
    print("키워드 매칭 결과:")
    for m in matches[:3]:
        print(f"  {m['pattern_id']}: {m['pattern_name']} (점수: {m['score']})")
